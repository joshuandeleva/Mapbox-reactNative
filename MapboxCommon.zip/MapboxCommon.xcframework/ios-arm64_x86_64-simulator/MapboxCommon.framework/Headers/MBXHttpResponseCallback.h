// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>

@class MBXHttpResponse;

/** Callback which is used to report result of HTTP request. */
NS_SWIFT_NAME(HttpResponseCallback)
typedef void (^MBXHttpResponseCallback)(MBXHttpResponse * _Nonnull response); // NOLINT(modernize-use-using)
