// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
@class MBXExpected<__covariant Value, __covariant Error>;

NS_SWIFT_NAME(BatteryChargingStatusCallback)
typedef void (^MBXBatteryChargingStatusCallback)(MBXExpected<NSNumber *, NSString *> * _Nonnull result); // NOLINT(modernize-use-using)
