// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>

// NOLINTNEXTLINE(modernize-use-using)
typedef NS_ENUM(NSInteger, MBXBillingServiceErrorCode)
{
    MBXBillingServiceErrorCodeTokenValidationFailed,
    MBXBillingServiceErrorCodeResumeFailed
} NS_SWIFT_NAME(BillingServiceErrorCode);

NSString* MBXBillingServiceErrorCodeToString(MBXBillingServiceErrorCode billing_service_error_code);
