// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>

// NOLINTNEXTLINE(modernize-use-using)
typedef NS_ENUM(NSInteger, MBXBillingSessionStatus)
{
    MBXBillingSessionStatusSessionActive,
    MBXBillingSessionStatusSessionPaused,
    MBXBillingSessionStatusNoSession
} NS_SWIFT_NAME(BillingSessionStatus);

NSString* MBXBillingSessionStatusToString(MBXBillingSessionStatus billing_session_status);
