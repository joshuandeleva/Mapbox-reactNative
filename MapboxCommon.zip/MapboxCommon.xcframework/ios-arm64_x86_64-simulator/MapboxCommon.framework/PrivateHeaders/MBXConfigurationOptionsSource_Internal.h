// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>

// NOLINTNEXTLINE(modernize-use-using)
typedef NS_ENUM(NSInteger, MBXConfigurationOptionsSource)
{
    MBXConfigurationOptionsSourceLocal,
    MBXConfigurationOptionsSourceServer
} NS_SWIFT_NAME(ConfigurationOptionsSource);

NSString* MBXConfigurationOptionsSourceToString(MBXConfigurationOptionsSource configuration_options_source);
