// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
@class MBXExpected<__covariant Value, __covariant Error>;

@class MBXConfigurationOptions;
@class MBXConfigurationServiceError;

NS_SWIFT_NAME(ConfigurationServiceGetConfigCallback)
typedef void (^MBXConfigurationServiceGetConfigCallback)(MBXExpected<MBXConfigurationOptions *, MBXConfigurationServiceError *> * _Nonnull result); // NOLINT(modernize-use-using)
