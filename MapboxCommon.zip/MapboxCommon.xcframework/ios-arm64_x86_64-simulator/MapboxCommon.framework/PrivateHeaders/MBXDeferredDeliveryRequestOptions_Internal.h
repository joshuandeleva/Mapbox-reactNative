// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>

NS_SWIFT_NAME(DeferredDeliveryRequestOptions)
__attribute__((visibility ("default")))
@interface MBXDeferredDeliveryRequestOptions : NSObject

- (nonnull instancetype)init;

- (nonnull instancetype)initWithTtl:(uint64_t)ttl;

@property (nonatomic, readonly) uint64_t ttl;

@end
