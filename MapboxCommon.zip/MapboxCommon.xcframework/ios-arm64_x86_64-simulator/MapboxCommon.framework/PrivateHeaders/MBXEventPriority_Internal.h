// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>

// NOLINTNEXTLINE(modernize-use-using)
typedef NS_ENUM(NSInteger, MBXEventPriority)
{
    MBXEventPriorityDeferred,
    MBXEventPriorityQueued,
    MBXEventPriorityImmediate
} NS_SWIFT_NAME(EventPriority);
