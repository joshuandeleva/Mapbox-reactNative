// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>

@class MBXEventsServiceError;

NS_SWIFT_NAME(EventsServiceResponseCallback)
typedef void (^MBXEventsServiceResponseCallback)(MBXEventsServiceError * _Nullable result); // NOLINT(modernize-use-using)
