// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
#import <MapboxCommon/MBXLifecycleMonitoringState_Internal.h>
@class MBXExpected<__covariant Value, __covariant Error>;

NS_SWIFT_NAME(GetLifecycleMonitoringStateCallback)
typedef void (^MBXGetLifecycleMonitoringStateCallback)(MBXExpected<NSNumber *, NSString *> * _Nonnull result); // NOLINT(modernize-use-using)
