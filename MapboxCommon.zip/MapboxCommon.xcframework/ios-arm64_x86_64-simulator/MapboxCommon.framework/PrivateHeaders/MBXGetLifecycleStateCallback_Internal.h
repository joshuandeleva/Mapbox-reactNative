// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
#import <MapboxCommon/MBXLifecycleState_Internal.h>
@class MBXExpected<__covariant Value, __covariant Error>;

NS_SWIFT_NAME(GetLifecycleStateCallback)
typedef void (^MBXGetLifecycleStateCallback)(MBXExpected<NSNumber *, NSString *> * _Nonnull result); // NOLINT(modernize-use-using)
