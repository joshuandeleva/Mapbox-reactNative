// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
@class MBXExpected<__covariant Value, __covariant Error>;

@class MBXLocation;
@class MBXLocationError;

NS_SWIFT_NAME(GetLocationCallback)
typedef void (^MBXGetLocationCallback)(MBXExpected<MBXLocation *, MBXLocationError *> * _Nonnull result); // NOLINT(modernize-use-using)
