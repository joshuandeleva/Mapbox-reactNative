// This file is generated and will be overwritten automatically.

#import <MapboxCommon/MBXLocationServiceFactory.h>

@interface MBXLocationServiceFactory ()
+ (void)setUserDefinedForCustom:(nonnull id<MBXLocationService>)custom;
+ (nonnull id<MBXLocationService>)locationService __attribute((ns_returns_retained));
@end
