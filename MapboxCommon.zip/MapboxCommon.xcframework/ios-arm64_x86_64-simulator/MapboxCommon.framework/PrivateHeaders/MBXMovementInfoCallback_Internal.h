// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
@class MBXExpected<__covariant Value, __covariant Error>;

@class MBXMovementInfo;

NS_SWIFT_NAME(MovementInfoCallback)
typedef void (^MBXMovementInfoCallback)(MBXExpected<MBXMovementInfo *, NSString *> * _Nonnull result); // NOLINT(modernize-use-using)
