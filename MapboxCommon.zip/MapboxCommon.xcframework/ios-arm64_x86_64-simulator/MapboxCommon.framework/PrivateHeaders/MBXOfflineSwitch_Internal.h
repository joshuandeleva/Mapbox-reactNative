// This file is generated and will be overwritten automatically.

#import <MapboxCommon/MBXOfflineSwitch.h>

@interface MBXOfflineSwitch ()
- (void)registerObserverForObserver:(nonnull id<MBXOfflineSwitchObserver>)observer;
- (void)unregisterObserverForObserver:(nonnull id<MBXOfflineSwitchObserver>)observer;
@end
