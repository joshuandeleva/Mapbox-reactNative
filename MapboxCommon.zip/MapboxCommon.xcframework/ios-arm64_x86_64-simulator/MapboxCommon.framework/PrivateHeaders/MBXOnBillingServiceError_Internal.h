// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>

@class MBXBillingServiceError;

NS_SWIFT_NAME(OnBillingServiceError)
typedef void (^MBXOnBillingServiceError)(MBXBillingServiceError * _Nonnull result); // NOLINT(modernize-use-using)
