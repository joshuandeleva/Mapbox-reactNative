// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>

NS_SWIFT_NAME(OnValueChanged)
typedef void (^MBXOnValueChanged)(NSString * _Nonnull key, id _Nullable oldValue, id _Nullable newValue); // NOLINT(modernize-use-using)
