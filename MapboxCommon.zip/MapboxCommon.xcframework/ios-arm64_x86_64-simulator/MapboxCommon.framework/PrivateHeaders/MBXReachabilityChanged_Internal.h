// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
#import <MapboxCommon/MBXNetworkStatus_Internal.h>

NS_SWIFT_NAME(ReachabilityChanged)
typedef void (^MBXReachabilityChanged)(MBXNetworkStatus status); // NOLINT(modernize-use-using)
