// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>

// NOLINTNEXTLINE(modernize-use-using)
typedef NS_ENUM(NSInteger, MBXResourceLoadErrorType)
{
    MBXResourceLoadErrorTypeErrored,
    MBXResourceLoadErrorTypeUnsatisfied,
    MBXResourceLoadErrorTypeCanceled,
    MBXResourceLoadErrorTypeInvalidArgument
} NS_SWIFT_NAME(ResourceLoadErrorType);
