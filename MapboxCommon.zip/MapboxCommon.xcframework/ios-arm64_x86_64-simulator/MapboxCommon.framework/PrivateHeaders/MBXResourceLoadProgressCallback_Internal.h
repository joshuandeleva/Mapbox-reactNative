// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>

@class MBXResourceLoadProgress;

NS_SWIFT_NAME(ResourceLoadProgressCallback)
typedef void (^MBXResourceLoadProgressCallback)(MBXResourceLoadProgress * _Nonnull progress); // NOLINT(modernize-use-using)
