// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
@class MBXExpected<__covariant Value, __covariant Error>;

@class MBXResourceLoadError;
@class MBXResourceLoadResult;

NS_SWIFT_NAME(ResourceLoadResultCallback)
typedef void (^MBXResourceLoadResultCallback)(MBXExpected<MBXResourceLoadResult *, MBXResourceLoadError *> * _Nonnull result); // NOLINT(modernize-use-using)
