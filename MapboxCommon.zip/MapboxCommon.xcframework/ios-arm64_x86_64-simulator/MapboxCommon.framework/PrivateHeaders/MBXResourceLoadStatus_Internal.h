// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>

// NOLINTNEXTLINE(modernize-use-using)
typedef NS_ENUM(NSInteger, MBXResourceLoadStatus)
{
    MBXResourceLoadStatusAvailable,
    MBXResourceLoadStatusNotFound,
    MBXResourceLoadStatusUnauthorized
} NS_SWIFT_NAME(ResourceLoadStatus);
