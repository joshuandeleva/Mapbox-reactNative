// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>

// NOLINTNEXTLINE(modernize-use-using)
typedef NS_ENUM(NSInteger, MBXSessionSKUIdentifier)
{
    MBXSessionSKUIdentifierNav2SesTrip,
    MBXSessionSKUIdentifierNav2SesFDTrip
} NS_SWIFT_NAME(SessionSKUIdentifier);

NSString* MBXSessionSKUIdentifierToString(MBXSessionSKUIdentifier session_skuidentifier);
