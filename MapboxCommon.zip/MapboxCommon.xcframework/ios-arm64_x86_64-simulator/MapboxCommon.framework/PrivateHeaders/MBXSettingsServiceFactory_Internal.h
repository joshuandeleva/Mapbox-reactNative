// This file is generated and will be overwritten automatically.

#import <MapboxCommon/MBXSettingsServiceFactory.h>

@interface MBXSettingsServiceFactory ()
+ (void)reset;
+ (nonnull id<MBXSettingsServiceInterface>)getInstanceForStorageType:(MBXSettingsServiceStorageType)storageType __attribute((ns_returns_retained));
@end
