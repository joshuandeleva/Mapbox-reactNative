// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
#import <MapboxCommon/MBXTelemetryCollectionState_Internal.h>

NS_SWIFT_NAME(TelemetryCollectionStateObserver)
@protocol MBXTelemetryCollectionStateObserver
- (void)onStateChangedForState:(MBXTelemetryCollectionState)state;
@end
