// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>

// NOLINTNEXTLINE(modernize-use-using)
typedef NS_ENUM(NSInteger, MBXTelemetryCollectionState)
{
    MBXTelemetryCollectionStateEnabled,
    MBXTelemetryCollectionStateTurnstileEventsOnly,
    MBXTelemetryCollectionStateUnknown
} NS_SWIFT_NAME(TelemetryCollectionState);

NSString* MBXTelemetryCollectionStateToString(MBXTelemetryCollectionState telemetry_collection_state);
