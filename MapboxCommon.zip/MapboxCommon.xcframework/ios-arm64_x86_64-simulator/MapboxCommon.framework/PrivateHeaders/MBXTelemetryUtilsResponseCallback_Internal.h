// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>

@class MBXEventsServiceError;

NS_SWIFT_NAME(TelemetryUtilsResponseCallback)
typedef void (^MBXTelemetryUtilsResponseCallback)(MBXEventsServiceError * _Nullable result); // NOLINT(modernize-use-using)
