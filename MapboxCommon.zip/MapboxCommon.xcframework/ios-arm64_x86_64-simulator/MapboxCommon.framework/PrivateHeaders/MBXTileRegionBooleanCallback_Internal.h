// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
@class MBXExpected<__covariant Value, __covariant Error>;

@class MBXTileRegionError;

NS_SWIFT_NAME(TileRegionBooleanCallback)
typedef void (^MBXTileRegionBooleanCallback)(MBXExpected<NSNumber *, MBXTileRegionError *> * _Nonnull result); // NOLINT(modernize-use-using)
