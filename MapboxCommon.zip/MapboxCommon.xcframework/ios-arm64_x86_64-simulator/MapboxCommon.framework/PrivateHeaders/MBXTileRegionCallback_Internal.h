// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
@class MBXExpected<__covariant Value, __covariant Error>;

@class MBXTileRegion;
@class MBXTileRegionError;

NS_SWIFT_NAME(TileRegionCallback)
typedef void (^MBXTileRegionCallback)(MBXExpected<MBXTileRegion *, MBXTileRegionError *> * _Nonnull region); // NOLINT(modernize-use-using)
