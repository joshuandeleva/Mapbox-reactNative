// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
@class MBXExpected<__covariant Value, __covariant Error>;
@class MBXGeometry;

@class MBXTileRegionError;

NS_SWIFT_NAME(TileRegionGeometryCallback)
typedef void (^MBXTileRegionGeometryCallback)(MBXExpected<MBXGeometry *, MBXTileRegionError *> * _Nonnull result); // NOLINT(modernize-use-using)
