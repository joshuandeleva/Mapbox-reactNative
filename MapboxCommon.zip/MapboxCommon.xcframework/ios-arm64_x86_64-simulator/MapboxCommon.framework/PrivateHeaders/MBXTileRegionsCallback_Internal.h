// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
@class MBXExpected<__covariant Value, __covariant Error>;

@class MBXTileRegion;
@class MBXTileRegionError;

NS_SWIFT_NAME(TileRegionsCallback)
typedef void (^MBXTileRegionsCallback)(MBXExpected<NSArray<MBXTileRegion *> *, MBXTileRegionError *> * _Nonnull regions); // NOLINT(modernize-use-using)
