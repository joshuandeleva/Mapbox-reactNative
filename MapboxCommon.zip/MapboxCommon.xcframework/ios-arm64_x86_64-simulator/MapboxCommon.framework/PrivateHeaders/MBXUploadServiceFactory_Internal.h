// This file is generated and will be overwritten automatically.

#import <MapboxCommon/MBXUploadServiceFactory.h>

@interface MBXUploadServiceFactory ()
+ (void)reset;
+ (nonnull id<MBXUploadServiceInterface>)getInstance __attribute((ns_returns_retained));
@end
