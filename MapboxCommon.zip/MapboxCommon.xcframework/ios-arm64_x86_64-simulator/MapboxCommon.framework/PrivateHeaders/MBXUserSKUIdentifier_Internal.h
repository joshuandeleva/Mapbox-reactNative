// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>

// NOLINTNEXTLINE(modernize-use-using)
typedef NS_ENUM(NSInteger, MBXUserSKUIdentifier)
{
    MBXUserSKUIdentifierMapsMAUS,
    MBXUserSKUIdentifierVisionMAUS,
    MBXUserSKUIdentifierVisionFleetMAUS,
    MBXUserSKUIdentifierNav2SesMAU
} NS_SWIFT_NAME(UserSKUIdentifier);

NSString* MBXUserSKUIdentifierToString(MBXUserSKUIdentifier user_skuidentifier);
