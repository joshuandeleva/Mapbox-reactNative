// This file is generated and will be overwritten automatically.

#import <MapboxCommon/MBXValueConverter.h>

@interface MBXValueConverter ()
+ (nonnull MBXExpected<id, NSString *> *)fromJsonForJson:(nonnull NSString *)json __attribute((ns_returns_retained)) NS_REFINED_FOR_SWIFT;
@end
