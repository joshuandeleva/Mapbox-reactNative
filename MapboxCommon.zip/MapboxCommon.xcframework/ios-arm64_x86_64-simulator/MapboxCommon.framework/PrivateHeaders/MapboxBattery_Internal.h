// This file is generated and will be overwritten automatically.

#import "MBXBatteryMonitorFactory_Internal.h"
#import "MBXBatteryMonitorObserver_Internal.h"
#import "MBXBatteryMonitorInterface_Internal.h"
#import "MBXBatteryChargingStatusCallback_Internal.h"
